// declare module
declare module 'vue-sweetalert2'
declare module 'vue-chart-3'
declare module '@fortawesome/fontawesome-svg-core'
declare module '@fortawesome/free-solid-svg-icons'
declare module '@fortawesome/free-brands-svg-icons'
